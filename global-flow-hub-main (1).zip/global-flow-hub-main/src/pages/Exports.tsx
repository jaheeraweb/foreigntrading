
import React, { useState } from "react";
import { Plus, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import PageHeader from "@/components/layout/PageHeader";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import ExportForm from "@/components/exports/ExportForm";

// Sample export data
const sampleExports = [
  {
    id: "EXP-2001",
    product: "Farm Equipment",
    client: "AgriTech Solutions",
    destination: "Kenya",
    amount: 187000,
    status: "active",
    departureDate: "2025-05-18"
  },
  {
    id: "EXP-2002",
    product: "Pharmaceuticals",
    client: "MediGlobal Inc",
    destination: "Australia",
    amount: 342000,
    status: "pending",
    departureDate: "2025-05-25"
  },
  {
    id: "EXP-2003",
    product: "Automotive Parts",
    client: "Vehicle Systems Ltd",
    destination: "Mexico",
    amount: 156000,
    status: "active",
    departureDate: "2025-05-20"
  },
  {
    id: "EXP-2004",
    product: "Consumer Goods",
    client: "Retail Enterprises",
    destination: "Canada",
    amount: 83500,
    status: "completed",
    departureDate: "2025-04-27"
  }
];

const statusColors = {
  active: "bg-green-100 text-green-700",
  pending: "bg-amber-100 text-amber-700",
  completed: "bg-blue-100 text-blue-700"
};

const Exports: React.FC = () => {
  const [exports, setExports] = useState(sampleExports);
  const [searchQuery, setSearchQuery] = useState("");
  const [isNewExportDialogOpen, setIsNewExportDialogOpen] = useState(false);
  const { toast } = useToast();
  
  const filteredExports = exports.filter(item => 
    item.product.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.client.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.id.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  const getFilteredExportsByStatus = (status: string) => {
    if (status === "all") return filteredExports;
    return filteredExports.filter(item => item.status === status);
  };
  
  const handleCreateNewExport = () => {
    setIsNewExportDialogOpen(true);
  };
  
  const handleExportCreated = (newExport: any) => {
    // Generate a new unique ID
    const newId = `EXP-${2000 + exports.length + 1}`;
    
    // Create a formatted date string from the date object
    const departureDate = newExport.departureDate instanceof Date 
      ? newExport.departureDate.toISOString().split('T')[0] 
      : new Date().toISOString().split('T')[0];
    
    // Create the new export object
    const exportToAdd = {
      id: newId,
      product: newExport.product,
      client: newExport.client,
      destination: newExport.destination,
      amount: parseFloat(newExport.amount) || 0,
      status: newExport.status,
      departureDate: departureDate
    };
    
    // Add the new export to the exports array
    setExports(current => [...current, exportToAdd]);
    
    // Close the dialog and show a success toast
    setIsNewExportDialogOpen(false);
    toast({
      title: "Export created",
      description: `Export for ${newExport.product} has been created successfully.`,
    });
  };

  return (
    <div className="space-y-6">
      <PageHeader title="Export Management" />
      
      <div className="flex justify-between flex-col sm:flex-row gap-4">
        <div className="relative w-full sm:w-80">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search exports..."
            className="pl-8 w-full"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Button 
          className="flex items-center gap-2"
          onClick={handleCreateNewExport}
        >
          <Plus className="h-4 w-4" /> New Export
        </Button>
      </div>
      
      <Tabs defaultValue="all" className="w-full">
        <TabsList className="mb-6">
          <TabsTrigger value="all">All Exports</TabsTrigger>
          <TabsTrigger value="active">Active</TabsTrigger>
          <TabsTrigger value="pending">Pending</TabsTrigger>
          <TabsTrigger value="completed">Completed</TabsTrigger>
        </TabsList>
        
        <TabsContent value="all">
          <ExportsTable exports={getFilteredExportsByStatus("all")} />
        </TabsContent>
        
        <TabsContent value="active">
          <ExportsTable exports={getFilteredExportsByStatus("active")} />
        </TabsContent>
        
        <TabsContent value="pending">
          <ExportsTable exports={getFilteredExportsByStatus("pending")} />
        </TabsContent>
        
        <TabsContent value="completed">
          <ExportsTable exports={getFilteredExportsByStatus("completed")} />
        </TabsContent>
      </Tabs>
      
      <Dialog open={isNewExportDialogOpen} onOpenChange={setIsNewExportDialogOpen}>
        <DialogContent className="sm:max-w-[550px]">
          <DialogHeader>
            <DialogTitle>Create New Export</DialogTitle>
            <DialogDescription>
              Fill in the details for the new export order.
            </DialogDescription>
          </DialogHeader>
          <ExportForm 
            onSuccess={handleExportCreated} 
            onCancel={() => setIsNewExportDialogOpen(false)} 
          />
        </DialogContent>
      </Dialog>
    </div>
  );
};

interface ExportItem {
  id: string;
  product: string;
  client: string;
  destination: string;
  amount: number;
  status: string;
  departureDate: string;
}

interface ExportsTableProps {
  exports: ExportItem[];
}

const ExportsTable: React.FC<ExportsTableProps> = ({ exports }) => {
  return (
    <Card>
      <CardContent className="p-0">
        {exports.length > 0 ? (
          <div className="rounded-md overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-muted/50">
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">ID</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Product</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Client</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Destination</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Amount</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Status</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Departure</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {exports.map((item) => (
                  <tr key={item.id} className="border-t hover:bg-muted/50">
                    <td className="whitespace-nowrap px-4 py-3 font-medium">{item.id}</td>
                    <td className="whitespace-nowrap px-4 py-3">{item.product}</td>
                    <td className="whitespace-nowrap px-4 py-3">{item.client}</td>
                    <td className="whitespace-nowrap px-4 py-3">{item.destination}</td>
                    <td className="whitespace-nowrap px-4 py-3">
                      {item.amount.toLocaleString('en-US', { 
                        style: 'currency', 
                        currency: 'USD',
                        maximumFractionDigits: 0
                      })}
                    </td>
                    <td className="whitespace-nowrap px-4 py-3">
                      <Badge 
                        variant="outline" 
                        className={statusColors[item.status as keyof typeof statusColors]}
                      >
                        {item.status}
                      </Badge>
                    </td>
                    <td className="whitespace-nowrap px-4 py-3">{item.departureDate}</td>
                    <td className="whitespace-nowrap px-4 py-3">
                      <Button variant="ghost" size="sm">View</Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No exports found</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default Exports;
