
import React from "react";
import { Import, ExternalLink, LineChart, DollarSign } from "lucide-react";
import PageHeader from "@/components/layout/PageHeader";
import StatCard from "@/components/dashboard/StatCard";
import TradeActivityChart from "@/components/dashboard/TradeActivityChart";
import RecentTradesList from "@/components/dashboard/RecentTradesList";
import TopCountriesCard from "@/components/dashboard/TopCountriesCard";
import MarketInsightsCard from "@/components/dashboard/MarketInsightsCard";

const Dashboard: React.FC = () => {
  return (
    <div className="space-y-6">
      <PageHeader 
        title="Dashboard" 
        description="Monitor and manage your trading activities"
      />
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard 
          title="Total Imports" 
          value="$12.4M" 
          description="Last 30 days"
          icon={<Import className="h-5 w-5" />}
          trend={{ value: 8.2, isPositive: true }}
        />
        <StatCard 
          title="Total Exports" 
          value="$9.8M" 
          description="Last 30 days"
          icon={<ExternalLink className="h-5 w-5" />}
          trend={{ value: 3.1, isPositive: true }}
        />
        <StatCard 
          title="Trading Balance" 
          value="$2.6M" 
          description="Last 30 days"
          icon={<DollarSign className="h-5 w-5" />}
          trend={{ value: 5.4, isPositive: true }}
        />
        <StatCard 
          title="Active Trades" 
          value="27" 
          description="14 Imports, 13 Exports"
          icon={<LineChart className="h-5 w-5" />}
          trend={{ value: 2.3, isPositive: false }}
        />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-3">
          <TradeActivityChart />
        </div>
        
        <div className="lg:col-span-1">
          <TopCountriesCard />
        </div>
        <div className="lg:col-span-2">
          <MarketInsightsCard />
        </div>
        
        <div className="lg:col-span-3">
          <RecentTradesList />
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
