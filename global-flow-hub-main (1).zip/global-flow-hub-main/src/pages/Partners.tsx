
import React, { useState } from "react";
import { Plus, Search, Mail, Phone, Globe } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import PageHeader from "@/components/layout/PageHeader";

interface Partner {
  id: string;
  name: string;
  type: "supplier" | "customer" | "distributor";
  location: string;
  contactPerson: string;
  email: string;
  phone: string;
  status: "active" | "inactive";
  website?: string;
}

const samplePartners: Partner[] = [
  {
    id: "PTN-1001",
    name: "Global Tech Solutions",
    type: "supplier",
    location: "Singapore",
    contactPerson: "Michael Wong",
    email: "m.wong@globaltech.com",
    phone: "+65 8765 4321",
    status: "active",
    website: "globaltech.com"
  },
  {
    id: "PTN-1002",
    name: "Rapid Logistics Inc",
    type: "distributor",
    location: "Netherlands",
    contactPerson: "Sophia van der Berg",
    email: "sophia@rapidlogistics.com",
    phone: "+31 20 123 4567",
    status: "active",
    website: "rapidlogistics.com"
  },
  {
    id: "PTN-1003",
    name: "Retail Partners Ltd",
    type: "customer",
    location: "United Kingdom",
    contactPerson: "James Wilson",
    email: "jwilson@retailpartners.co.uk",
    phone: "+44 20 7946 0982",
    status: "active",
    website: "retailpartners.co.uk"
  },
  {
    id: "PTN-1004",
    name: "Agricultural Exports Co",
    type: "customer",
    location: "Brazil",
    contactPerson: "Sofia Pereira",
    email: "sofia@agriexports.br",
    phone: "+55 11 3456 7890",
    status: "inactive"
  },
  {
    id: "PTN-1005",
    name: "Pacific Manufacturing",
    type: "supplier",
    location: "Japan",
    contactPerson: "Takashi Yamada",
    email: "takashi@pacificmfg.jp",
    phone: "+81 3 1234 5678",
    status: "active",
    website: "pacificmfg.jp"
  }
];

const Partners: React.FC = () => {
  const [partners, setPartners] = useState<Partner[]>(samplePartners);
  const [searchQuery, setSearchQuery] = useState("");
  const { toast } = useToast();
  
  const filteredPartners = partners.filter(partner => 
    partner.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    partner.contactPerson.toLowerCase().includes(searchQuery.toLowerCase()) ||
    partner.location.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  const handleAddPartner = () => {
    toast({
      title: "Add New Partner",
      description: "This functionality will be available soon",
    });
  };

  const filterPartnersByType = (type: string) => {
    if (type === "all") return filteredPartners;
    return filteredPartners.filter(partner => partner.type === type);
  };

  return (
    <div className="space-y-6">
      <PageHeader 
        title="Partners" 
        description="Manage your trading partners and relationships"
      />
      
      <div className="flex justify-between flex-col sm:flex-row gap-4">
        <div className="relative w-full sm:w-80">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search partners..."
            className="pl-8 w-full"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Button 
          className="flex items-center gap-2"
          onClick={handleAddPartner}
        >
          <Plus className="h-4 w-4" /> Add Partner
        </Button>
      </div>
      
      <Tabs defaultValue="all" className="w-full">
        <TabsList className="mb-6">
          <TabsTrigger value="all">All Partners</TabsTrigger>
          <TabsTrigger value="supplier">Suppliers</TabsTrigger>
          <TabsTrigger value="customer">Customers</TabsTrigger>
          <TabsTrigger value="distributor">Distributors</TabsTrigger>
        </TabsList>
        
        <TabsContent value="all">
          <PartnersGrid partners={filteredPartners} />
        </TabsContent>
        
        <TabsContent value="supplier">
          <PartnersGrid partners={filterPartnersByType("supplier")} />
        </TabsContent>
        
        <TabsContent value="customer">
          <PartnersGrid partners={filterPartnersByType("customer")} />
        </TabsContent>
        
        <TabsContent value="distributor">
          <PartnersGrid partners={filterPartnersByType("distributor")} />
        </TabsContent>
      </Tabs>
    </div>
  );
};

interface PartnersGridProps {
  partners: Partner[];
}

const PartnersGrid: React.FC<PartnersGridProps> = ({ partners }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {partners.length > 0 ? (
        partners.map(partner => (
          <Card key={partner.id} className="overflow-hidden">
            <CardContent className="p-0">
              <div className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-lg font-semibold">{partner.name}</h3>
                    <p className="text-sm text-muted-foreground">{partner.location}</p>
                  </div>
                  <Badge variant={partner.status === "active" ? "default" : "outline"}>
                    {partner.status}
                  </Badge>
                </div>
                
                <div className="space-y-3">
                  <div className="flex gap-2">
                    <span className="font-medium text-sm">Type:</span>
                    <span className="text-sm capitalize">{partner.type}</span>
                  </div>
                  <div className="flex gap-2">
                    <span className="font-medium text-sm">Contact:</span>
                    <span className="text-sm">{partner.contactPerson}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Mail className="h-4 w-4 text-muted-foreground" />
                    <a href={`mailto:${partner.email}`} className="text-sm hover:underline">{partner.email}</a>
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">{partner.phone}</span>
                  </div>
                  {partner.website && (
                    <div className="flex items-center gap-2">
                      <Globe className="h-4 w-4 text-muted-foreground" />
                      <a 
                        href={`https://${partner.website}`} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-sm hover:underline"
                      >
                        {partner.website}
                      </a>
                    </div>
                  )}
                </div>
              </div>
              <div className="bg-muted/50 p-3 border-t flex justify-end">
                <Button variant="ghost" size="sm">View Details</Button>
              </div>
            </CardContent>
          </Card>
        ))
      ) : (
        <div className="col-span-full text-center py-12">
          <p className="text-muted-foreground">No partners found matching your criteria</p>
        </div>
      )}
    </div>
  );
};

export default Partners;
