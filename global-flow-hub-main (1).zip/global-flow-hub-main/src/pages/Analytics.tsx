
import React from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell, AreaChart, Area, ScatterChart, Scatter, ZAxis, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from "recharts";
import PageHeader from "@/components/layout/PageHeader";

const monthlyData = [
  { name: "Jan", imports: 4000, exports: 2400 },
  { name: "Feb", imports: 3000, exports: 1398 },
  { name: "Mar", imports: 2000, exports: 9800 },
  { name: "Apr", imports: 2780, exports: 3908 },
  { name: "May", imports: 1890, exports: 4800 },
  { name: "Jun", imports: 2390, exports: 3800 },
  { name: "Jul", imports: 3490, exports: 4300 },
  { name: "Aug", imports: 4000, exports: 2400 },
  { name: "Sep", imports: 3000, exports: 1398 },
  { name: "Oct", imports: 2000, exports: 9800 },
  { name: "Nov", imports: 2780, exports: 3908 },
  { name: "Dec", imports: 1890, exports: 4800 },
];

const categoryData = [
  { name: "Electronics", value: 35 },
  { name: "Machinery", value: 25 },
  { name: "Textiles", value: 20 },
  { name: "Chemicals", value: 15 },
  { name: "Others", value: 5 },
];

const importsByCountry = [
  { name: "China", value: 45 },
  { name: "Germany", value: 20 },
  { name: "India", value: 15 },
  { name: "Brazil", value: 12 },
  { name: "Others", value: 8 },
];

const exportsByCountry = [
  { name: "USA", value: 35 },
  { name: "EU", value: 30 },
  { name: "Japan", value: 15 },
  { name: "Australia", value: 12 },
  { name: "Others", value: 8 },
];

const productPerformance = [
  { name: "Electronics", sales: 70, growth: 12, revenue: 85 },
  { name: "Machinery", sales: 60, growth: 8, revenue: 75 },
  { name: "Textiles", sales: 45, growth: -5, revenue: 40 },
  { name: "Chemicals", sales: 65, growth: 15, revenue: 55 },
  { name: "Automotive", sales: 80, growth: 20, revenue: 90 },
];

const quarterlyImports = [
  { name: "Q1", electronics: 2400, machinery: 1800, textiles: 1200, chemicals: 900 },
  { name: "Q2", electronics: 3200, machinery: 1500, textiles: 800, chemicals: 1100 },
  { name: "Q3", electronics: 2800, machinery: 2200, textiles: 1400, chemicals: 1300 },
  { name: "Q4", electronics: 3600, machinery: 2500, textiles: 1100, chemicals: 1500 },
];

const quarterlyExports = [
  { name: "Q1", electronics: 1800, machinery: 1200, textiles: 900, chemicals: 600 },
  { name: "Q2", electronics: 2400, machinery: 1100, textiles: 700, chemicals: 800 },
  { name: "Q3", electronics: 2100, machinery: 1800, textiles: 1100, chemicals: 900 },
  { name: "Q4", electronics: 2800, machinery: 2100, textiles: 800, chemicals: 1100 },
];

const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884d8"];

const Analytics: React.FC = () => {
  return (
    <div className="space-y-6">
      <PageHeader 
        title="Analytics" 
        description="Comprehensive trading performance analytics"
      />
      
      <Tabs defaultValue="overview">
        <TabsList className="mb-6">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="imports">Import Analysis</TabsTrigger>
          <TabsTrigger value="exports">Export Analysis</TabsTrigger>
          <TabsTrigger value="products">Products</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Monthly Trading Volume</CardTitle>
              <CardDescription>Comparison of import and export volumes over the last 12 months</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={monthlyData}
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="imports" name="Imports" fill="#003D81" />
                    <Bar dataKey="exports" name="Exports" fill="#3389F6" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Trading Trends</CardTitle>
                <CardDescription>Year-over-year comparison</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={monthlyData}
                      margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="imports" name="Imports" stroke="#003D81" strokeWidth={2} />
                      <Line type="monotone" dataKey="exports" name="Exports" stroke="#3389F6" strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Product Categories</CardTitle>
                <CardDescription>Distribution by product type</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={categoryData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={100}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {categoryData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="imports" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Import Sources</CardTitle>
                <CardDescription>Top countries by import volume</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={importsByCountry}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={100}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {importsByCountry.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Quarterly Import by Category</CardTitle>
                <CardDescription>Product category breakdown by quarter</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart
                      data={quarterlyImports}
                      margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Area type="monotone" dataKey="electronics" stackId="1" stroke="#8884d8" fill="#8884d8" />
                      <Area type="monotone" dataKey="machinery" stackId="1" stroke="#82ca9d" fill="#82ca9d" />
                      <Area type="monotone" dataKey="textiles" stackId="1" stroke="#ffc658" fill="#ffc658" />
                      <Area type="monotone" dataKey="chemicals" stackId="1" stroke="#ff8042" fill="#ff8042" />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Import Trends by Month</CardTitle>
                <CardDescription>Monthly import volume and growth rate</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[350px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={monthlyData}
                      margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis yAxisId="left" />
                      <YAxis yAxisId="right" orientation="right" />
                      <Tooltip />
                      <Legend />
                      <Line yAxisId="left" type="monotone" dataKey="imports" name="Import Value" stroke="#8884d8" activeDot={{ r: 8 }} />
                      <Line yAxisId="right" type="monotone" dataKey="exports" name="Export Value" stroke="#82ca9d" />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="exports" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Export Destinations</CardTitle>
                <CardDescription>Top markets by export volume</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={exportsByCountry}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={100}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {exportsByCountry.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Quarterly Export by Category</CardTitle>
                <CardDescription>Product category breakdown by quarter</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart
                      data={quarterlyExports}
                      margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Area type="monotone" dataKey="electronics" stackId="1" stroke="#8884d8" fill="#8884d8" />
                      <Area type="monotone" dataKey="machinery" stackId="1" stroke="#82ca9d" fill="#82ca9d" />
                      <Area type="monotone" dataKey="textiles" stackId="1" stroke="#ffc658" fill="#ffc658" />
                      <Area type="monotone" dataKey="chemicals" stackId="1" stroke="#ff8042" fill="#ff8042" />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Export Growth Rates</CardTitle>
                <CardDescription>Year-over-year export growth by month</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[350px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={monthlyData}
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="exports" name="Export Value" fill="#3389F6" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="products" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Product Performance</CardTitle>
              <CardDescription>Sales, growth, and revenue by product category</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <RadarChart outerRadius={150} width={730} height={350} data={productPerformance}>
                    <PolarGrid />
                    <PolarAngleAxis dataKey="name" />
                    <PolarRadiusAxis angle={30} domain={[0, 100]} />
                    <Radar name="Sales" dataKey="sales" stroke="#8884d8" fill="#8884d8" fillOpacity={0.6} />
                    <Radar name="Growth" dataKey="growth" stroke="#82ca9d" fill="#82ca9d" fillOpacity={0.6} />
                    <Radar name="Revenue" dataKey="revenue" stroke="#ffc658" fill="#ffc658" fillOpacity={0.6} />
                    <Legend />
                    <Tooltip />
                  </RadarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Top Performing Products</CardTitle>
                <CardDescription>Revenue vs. Growth comparison</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[350px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <ScatterChart
                      margin={{ top: 20, right: 20, bottom: 20, left: 20 }}
                    >
                      <CartesianGrid />
                      <XAxis type="number" dataKey="sales" name="Sales" />
                      <YAxis type="number" dataKey="growth" name="Growth" />
                      <ZAxis type="number" dataKey="revenue" range={[100, 500]} name="Revenue" />
                      <Tooltip cursor={{ strokeDasharray: "3 3" }} />
                      <Legend />
                      <Scatter name="Products" data={productPerformance} fill="#8884d8" />
                    </ScatterChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Product Revenue Breakdown</CardTitle>
                <CardDescription>Revenue contribution by product</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[350px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={productPerformance}
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                      layout="vertical"
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis type="number" />
                      <YAxis type="category" dataKey="name" />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="revenue" name="Revenue" fill="#8884d8" />
                      <Bar dataKey="sales" name="Sales" fill="#82ca9d" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Analytics;
