
import React, { useState } from "react";
import { Search, User, Clock, Send, Plus, ChevronRight } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";
import PageHeader from "@/components/layout/PageHeader";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import MessageDetail from "@/components/messages/MessageDetail";
import MessageReply from "@/components/messages/MessageReply";
import { Textarea } from "@/components/ui/textarea";

interface Message {
  id: string;
  sender: {
    name: string;
    avatar?: string;
    initials: string;
  };
  subject: string;
  preview: string;
  content: string;
  timestamp: string;
  read: boolean;
}

const inboxMessages: Message[] = [
  {
    id: "msg-1",
    sender: {
      name: "Michael Wong",
      initials: "MW",
    },
    subject: "Shipment Confirmation",
    preview: "The shipment of electronics from Singapore has been confirmed and will...",
    content: "The shipment of electronics from Singapore has been confirmed and will arrive at the port on May 15th. Please prepare the necessary documentation for customs clearance. Let me know if you need any additional information regarding this shipment.",
    timestamp: "09:45 AM",
    read: false
  },
  {
    id: "msg-2",
    sender: {
      name: "Sophia van der Berg",
      avatar: "https://i.pravatar.cc/150?u=sophia",
      initials: "SB",
    },
    subject: "Distribution Agreement",
    preview: "I've reviewed the distribution agreement and everything looks good to...",
    content: "I've reviewed the distribution agreement and everything looks good to proceed. However, there are a few clauses in section 4 regarding exclusivity that we may want to revisit. Can we schedule a call to discuss these points in more detail?",
    timestamp: "Yesterday",
    read: true
  },
  {
    id: "msg-3",
    sender: {
      name: "James Wilson",
      initials: "JW",
    },
    subject: "Order Increase Request",
    preview: "Due to increased demand, we would like to increase our next order by...",
    content: "Due to increased demand in our European markets, we would like to increase our next order by 30%. This would bring the total to approximately 1,300 units. Please confirm if this is possible within our existing timeline, or if we need to adjust the delivery schedule.",
    timestamp: "Apr 29",
    read: true
  },
  {
    id: "msg-4",
    sender: {
      name: "Sofia Pereira",
      avatar: "https://i.pravatar.cc/150?u=sofia",
      initials: "SP",
    },
    subject: "Payment Confirmation",
    preview: "This is to confirm that payment for invoice #3456 has been processed...",
    content: "This is to confirm that payment for invoice #3456 has been processed and should be reflected in your accounts within the next 2-3 business days. Please let me know if you have any questions regarding this transaction.",
    timestamp: "Apr 28",
    read: true
  }
];

const sentMessages: Message[] = [
  {
    id: "msg-s1",
    sender: {
      name: "You",
      initials: "JD",
    },
    subject: "RE: Shipment Schedule",
    preview: "Thank you for the update. Please confirm if the delivery date is...",
    content: "Thank you for the update. Please confirm if the delivery date is still set for May 20th. We need to coordinate with our logistics team to ensure smooth processing upon arrival.",
    timestamp: "10:23 AM",
    read: true
  },
  {
    id: "msg-s2",
    sender: {
      name: "You",
      initials: "JD",
    },
    subject: "Updated Price List",
    preview: "Please find attached our updated price list for Q2 2025. Please note...",
    content: "Please find attached our updated price list for Q2 2025. Please note that there have been some adjustments to the pricing of electronic components due to global supply chain issues. Let me know if you have any questions.",
    timestamp: "Yesterday",
    read: true
  },
  {
    id: "msg-s3",
    sender: {
      name: "You",
      initials: "JD",
    },
    subject: "Import Requirements",
    preview: "Here are the specific requirements for the import documentation...",
    content: "Here are the specific requirements for the import documentation we discussed earlier. It's important that all certificates of origin are properly authenticated and stamped by the respective chambers of commerce. This will help avoid any delays during customs clearance.",
    timestamp: "Apr 28",
    read: true
  }
];

const Messages: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedMessage, setSelectedMessage] = useState<Message | null>(null);
  const [isComposeDialogOpen, setIsComposeDialogOpen] = useState(false);
  const [newMessageContent, setNewMessageContent] = useState("");
  const [newMessageSubject, setNewMessageSubject] = useState("");
  const { toast } = useToast();
  
  const filteredInbox = inboxMessages.filter(message =>
    message.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
    message.sender.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    message.preview.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  const filteredSent = sentMessages.filter(message =>
    message.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
    message.preview.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  const handleOpenMessage = (message: Message) => {
    setSelectedMessage(message);
    
    // Mark message as read if it wasn't already
    if (!message.read) {
      const updatedMessage = { ...message, read: true };
      // In a real app, you would update the message in your backend
    }
  };
  
  const handleComposeMessage = () => {
    setIsComposeDialogOpen(true);
  };
  
  const handleSendNewMessage = () => {
    if (!newMessageSubject.trim() || !newMessageContent.trim()) {
      return;
    }
    
    toast({
      title: "Message sent",
      description: "Your message has been sent successfully.",
    });
    
    setNewMessageSubject("");
    setNewMessageContent("");
    setIsComposeDialogOpen(false);
  };

  // If a message is selected, show the message detail view
  if (selectedMessage) {
    return (
      <div className="space-y-6">
        <PageHeader title="Messages" description="Communicate with your trading partners" />
        
        <Card>
          <CardContent className="p-6">
            <MessageDetail 
              message={selectedMessage}
              onBack={() => setSelectedMessage(null)}
            />
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Messages" description="Communicate with your trading partners" />
      
      <div className="flex flex-col sm:flex-row justify-between gap-4">
        <div className="relative w-full sm:w-80">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search messages..."
            className="pl-8 w-full"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Button 
          className="flex items-center gap-2"
          onClick={handleComposeMessage}
        >
          <Plus className="h-4 w-4" /> Compose
        </Button>
      </div>
      
      <div className="grid grid-cols-1 gap-6">
        <Card>
          <Tabs defaultValue="inbox" className="w-full">
            <CardHeader className="pb-0">
              <div className="flex items-center justify-between">
                <CardTitle>Messages</CardTitle>
                <TabsList>
                  <TabsTrigger value="inbox">
                    Inbox
                    <Badge variant="outline" className="ml-2 bg-primary text-white">
                      {inboxMessages.filter(msg => !msg.read).length}
                    </Badge>
                  </TabsTrigger>
                  <TabsTrigger value="sent">Sent</TabsTrigger>
                </TabsList>
              </div>
            </CardHeader>
            
            <CardContent className="pt-6">
              <TabsContent value="inbox" className="m-0">
                {filteredInbox.length > 0 ? (
                  <div className="divide-y">
                    {filteredInbox.map(message => (
                      <div 
                        key={message.id} 
                        className={`py-3 px-2 hover:bg-muted/50 cursor-pointer ${!message.read ? 'bg-muted/30' : ''}`}
                        onClick={() => handleOpenMessage(message)}
                      >
                        <div className="flex items-center gap-3">
                          <Avatar>
                            <AvatarImage src={message.sender.avatar} />
                            <AvatarFallback>{message.sender.initials}</AvatarFallback>
                          </Avatar>
                          
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between">
                              <p className={`font-medium truncate ${!message.read ? 'font-semibold' : ''}`}>
                                {message.sender.name}
                              </p>
                              <div className="flex items-center">
                                <time className="text-sm text-muted-foreground whitespace-nowrap">
                                  {message.timestamp}
                                </time>
                                {!message.read && (
                                  <div className="ml-2 h-2 w-2 rounded-full bg-primary" />
                                )}
                              </div>
                            </div>
                            
                            <p className={`text-sm truncate ${!message.read ? 'font-medium' : ''}`}>
                              {message.subject}
                            </p>
                            <p className="text-sm text-muted-foreground truncate">
                              {message.preview}
                            </p>
                          </div>
                          
                          <ChevronRight className="h-4 w-4 text-muted-foreground" />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-muted-foreground">No messages found</p>
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="sent" className="m-0">
                {filteredSent.length > 0 ? (
                  <div className="divide-y">
                    {filteredSent.map(message => (
                      <div 
                        key={message.id} 
                        className="py-3 px-2 hover:bg-muted/50 cursor-pointer"
                        onClick={() => handleOpenMessage(message)}
                      >
                        <div className="flex items-center gap-3">
                          <div className="flex items-center justify-center h-10 w-10 rounded-full bg-primary/10 text-primary">
                            <Send className="h-4 w-4" />
                          </div>
                          
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between">
                              <p className="font-medium truncate">
                                {message.subject}
                              </p>
                              <time className="text-sm text-muted-foreground whitespace-nowrap">
                                {message.timestamp}
                              </time>
                            </div>
                            <p className="text-sm text-muted-foreground truncate">
                              {message.preview}
                            </p>
                          </div>
                          
                          <ChevronRight className="h-4 w-4 text-muted-foreground" />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-muted-foreground">No sent messages found</p>
                  </div>
                )}
              </TabsContent>
            </CardContent>
          </Tabs>
        </Card>
      </div>
      
      <Dialog open={isComposeDialogOpen} onOpenChange={setIsComposeDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Compose New Message</DialogTitle>
            <DialogDescription>
              Send a message to one of your trading partners.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <label htmlFor="recipient" className="text-sm font-medium">To:</label>
              <Input 
                id="recipient" 
                placeholder="Enter recipient name or email" 
              />
            </div>
            
            <div className="space-y-2">
              <label htmlFor="subject" className="text-sm font-medium">Subject:</label>
              <Input 
                id="subject" 
                placeholder="Message subject" 
                value={newMessageSubject}
                onChange={(e) => setNewMessageSubject(e.target.value)}
              />
            </div>
            
            <div className="space-y-2">
              <label htmlFor="message" className="text-sm font-medium">Message:</label>
              <Textarea 
                id="message" 
                placeholder="Type your message here..." 
                className="min-h-[150px]"
                value={newMessageContent}
                onChange={(e) => setNewMessageContent(e.target.value)}
              />
            </div>
          </div>
          
          <div className="flex justify-end gap-2 pt-2">
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => setIsComposeDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button 
              type="button" 
              onClick={handleSendNewMessage}
              disabled={!newMessageSubject.trim() || !newMessageContent.trim()}
              className="flex items-center gap-1"
            >
              <Send className="h-4 w-4" /> Send Message
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Messages;
