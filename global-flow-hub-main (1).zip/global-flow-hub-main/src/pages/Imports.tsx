
import React, { useState } from "react";
import { Plus, Search, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import PageHeader from "@/components/layout/PageHeader";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import ImportForm from "@/components/imports/ImportForm";

// Sample import data
const sampleImports = [
  {
    id: "IMP-1001",
    product: "Electronics",
    supplier: "Tech Global Ltd",
    origin: "China",
    amount: 156000,
    status: "active",
    arrivalDate: "2025-05-15"
  },
  {
    id: "IMP-1002",
    product: "Textiles",
    supplier: "Fabric World Co",
    origin: "India",
    amount: 78500,
    status: "pending",
    arrivalDate: "2025-05-22"
  },
  {
    id: "IMP-1003",
    product: "Machinery",
    supplier: "Industrial Systems",
    origin: "Germany",
    amount: 235000,
    status: "active",
    arrivalDate: "2025-05-18"
  },
  {
    id: "IMP-1004",
    product: "Raw Materials",
    supplier: "Resource Inc",
    origin: "Brazil",
    amount: 92000,
    status: "completed",
    arrivalDate: "2025-04-29"
  }
];

const statusColors = {
  active: "bg-green-100 text-green-700",
  pending: "bg-amber-100 text-amber-700",
  completed: "bg-blue-100 text-blue-700"
};

const Imports: React.FC = () => {
  const [imports, setImports] = useState(sampleImports);
  const [searchQuery, setSearchQuery] = useState("");
  const [isNewImportDialogOpen, setIsNewImportDialogOpen] = useState(false);
  const { toast } = useToast();
  
  const filteredImports = imports.filter(item => 
    item.product.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.supplier.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.id.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  const getFilteredImportsByStatus = (status: string) => {
    if (status === "all") return filteredImports;
    return filteredImports.filter(item => item.status === status);
  };
  
  const handleCreateNewImport = () => {
    setIsNewImportDialogOpen(true);
  };
  
  const handleImportCreated = (newImport: any) => {
    // Generate a new unique ID
    const newId = `IMP-${1000 + imports.length + 1}`;
    
    // Create a formatted date string from the date object
    const arrivalDate = newImport.arrivalDate instanceof Date 
      ? newImport.arrivalDate.toISOString().split('T')[0] 
      : new Date().toISOString().split('T')[0];
    
    // Create the new import object
    const importToAdd = {
      id: newId,
      product: newImport.product,
      supplier: newImport.supplier,
      origin: newImport.origin,
      amount: parseFloat(newImport.amount) || 0,
      status: newImport.status,
      arrivalDate: arrivalDate
    };
    
    // Add the new import to the imports array
    setImports(current => [...current, importToAdd]);
    
    // Close the dialog and show a success toast
    setIsNewImportDialogOpen(false);
    toast({
      title: "Import created",
      description: `Import for ${newImport.product} has been created successfully.`,
    });
  };

  return (
    <div className="space-y-6">
      <PageHeader title="Import Management" />
      
      <div className="flex justify-between flex-col sm:flex-row gap-4">
        <div className="relative w-full sm:w-80">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search imports..."
            className="pl-8 w-full"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Button 
          className="flex items-center gap-2" 
          onClick={handleCreateNewImport}
        >
          <Plus className="h-4 w-4" /> New Import
        </Button>
      </div>
      
      <Tabs defaultValue="all" className="w-full">
        <TabsList className="mb-6">
          <TabsTrigger value="all">All Imports</TabsTrigger>
          <TabsTrigger value="active">Active</TabsTrigger>
          <TabsTrigger value="pending">Pending</TabsTrigger>
          <TabsTrigger value="completed">Completed</TabsTrigger>
        </TabsList>
        
        <TabsContent value="all">
          <ImportsTable imports={getFilteredImportsByStatus("all")} />
        </TabsContent>
        
        <TabsContent value="active">
          <ImportsTable imports={getFilteredImportsByStatus("active")} />
        </TabsContent>
        
        <TabsContent value="pending">
          <ImportsTable imports={getFilteredImportsByStatus("pending")} />
        </TabsContent>
        
        <TabsContent value="completed">
          <ImportsTable imports={getFilteredImportsByStatus("completed")} />
        </TabsContent>
      </Tabs>
      
      <Dialog open={isNewImportDialogOpen} onOpenChange={setIsNewImportDialogOpen}>
        <DialogContent className="sm:max-w-[550px]">
          <DialogHeader>
            <DialogTitle>Create New Import</DialogTitle>
            <DialogDescription>
              Fill in the details for the new import order.
            </DialogDescription>
          </DialogHeader>
          <ImportForm 
            onSuccess={handleImportCreated} 
            onCancel={() => setIsNewImportDialogOpen(false)} 
          />
        </DialogContent>
      </Dialog>
    </div>
  );
};

interface ImportItem {
  id: string;
  product: string;
  supplier: string;
  origin: string;
  amount: number;
  status: string;
  arrivalDate: string;
}

interface ImportsTableProps {
  imports: ImportItem[];
}

const ImportsTable: React.FC<ImportsTableProps> = ({ imports }) => {
  return (
    <Card>
      <CardContent className="p-0">
        {imports.length > 0 ? (
          <div className="rounded-md overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-muted/50">
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">ID</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Product</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Supplier</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Origin</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Amount</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Status</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Arrival</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {imports.map((item) => (
                  <tr key={item.id} className="border-t hover:bg-muted/50">
                    <td className="whitespace-nowrap px-4 py-3 font-medium">{item.id}</td>
                    <td className="whitespace-nowrap px-4 py-3">{item.product}</td>
                    <td className="whitespace-nowrap px-4 py-3">{item.supplier}</td>
                    <td className="whitespace-nowrap px-4 py-3">{item.origin}</td>
                    <td className="whitespace-nowrap px-4 py-3">
                      {item.amount.toLocaleString('en-US', { 
                        style: 'currency', 
                        currency: 'USD',
                        maximumFractionDigits: 0
                      })}
                    </td>
                    <td className="whitespace-nowrap px-4 py-3">
                      <Badge 
                        variant="outline" 
                        className={statusColors[item.status as keyof typeof statusColors]}
                      >
                        {item.status}
                      </Badge>
                    </td>
                    <td className="whitespace-nowrap px-4 py-3">{item.arrivalDate}</td>
                    <td className="whitespace-nowrap px-4 py-3">
                      <Button variant="ghost" size="sm">View</Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No imports found</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default Imports;
