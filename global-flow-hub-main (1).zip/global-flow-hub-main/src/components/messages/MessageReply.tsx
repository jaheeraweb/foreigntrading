
import React, { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Send } from "lucide-react";

interface MessageReplyProps {
  messageId: string;
  onSuccess: () => void;
  onCancel?: () => void;
}

const MessageReply: React.FC<MessageReplyProps> = ({ messageId, onSuccess, onCancel }) => {
  const [message, setMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSend = () => {
    if (!message.trim()) {
      return;
    }

    setIsLoading(true);

    // Simulate API call
    setTimeout(() => {
      console.log("Sent reply to message:", messageId, "Content:", message);
      
      toast({
        title: "Reply sent",
        description: "Your message has been sent successfully.",
      });
      
      setMessage("");
      setIsLoading(false);
      onSuccess();
    }, 800);
  };

  return (
    <div className="space-y-4">
      <Textarea
        placeholder="Type your reply here..."
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        className="min-h-[100px]"
        disabled={isLoading}
      />
      
      <div className="flex justify-end gap-2">
        {onCancel && (
          <Button 
            type="button" 
            variant="outline" 
            onClick={onCancel}
            disabled={isLoading}
          >
            Cancel
          </Button>
        )}
        <Button 
          type="button" 
          onClick={handleSend}
          disabled={!message.trim() || isLoading}
          className="flex items-center gap-1"
        >
          <Send className="h-4 w-4" /> Send Reply
        </Button>
      </div>
    </div>
  );
};

export default MessageReply;
