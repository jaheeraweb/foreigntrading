
import React, { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ChevronLeft, Reply, User } from "lucide-react";
import MessageReply from "./MessageReply";
import { format } from "date-fns";

interface MessageDetailProps {
  message: {
    id: string;
    sender: {
      name: string;
      avatar?: string;
      initials: string;
    };
    subject: string;
    content: string;
    timestamp: string;
    read: boolean;
  };
  onBack: () => void;
}

const MessageDetail: React.FC<MessageDetailProps> = ({ message, onBack }) => {
  const [showReplyForm, setShowReplyForm] = useState(false);
  const { toast } = useToast();

  const handleReplySuccess = () => {
    setShowReplyForm(false);
    toast({
      title: "Reply sent",
      description: "Your reply has been sent successfully.",
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between mb-4">
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={onBack} 
          className="flex items-center gap-1 text-muted-foreground"
        >
          <ChevronLeft className="h-4 w-4" /> Back to Messages
        </Button>
        
        {!showReplyForm && (
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => setShowReplyForm(true)}
            className="flex items-center gap-1"
          >
            <Reply className="h-4 w-4" /> Reply
          </Button>
        )}
      </div>
      
      <div className="border-b pb-4">
        <h2 className="text-xl font-semibold mb-2">{message.subject}</h2>
        
        <div className="flex items-center gap-3 mt-4">
          <Avatar>
            <AvatarImage src={message.sender.avatar} />
            <AvatarFallback>{message.sender.initials}</AvatarFallback>
          </Avatar>
          
          <div>
            <p className="font-medium">{message.sender.name}</p>
            <p className="text-xs text-muted-foreground">
              {format(new Date(), "PPP 'at' p")}
            </p>
          </div>
        </div>
      </div>
      
      <div className="prose prose-sm max-w-none">
        <p>{message.content}</p>
      </div>
      
      {showReplyForm && (
        <div className="mt-6 border-t pt-4">
          <h3 className="text-lg font-medium mb-4">Reply</h3>
          <MessageReply 
            messageId={message.id}
            onSuccess={handleReplySuccess}
            onCancel={() => setShowReplyForm(false)}
          />
        </div>
      )}
    </div>
  );
};

export default MessageDetail;
