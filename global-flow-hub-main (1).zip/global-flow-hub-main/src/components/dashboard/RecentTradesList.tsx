
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";

interface Trade {
  id: string;
  product: string;
  country: string;
  amount: number;
  status: "completed" | "pending" | "processing";
  date: string;
  type: "import" | "export";
}

const recentTrades: Trade[] = [
  {
    id: "TR-7829",
    product: "Electronics",
    country: "China",
    amount: 356000,
    status: "completed",
    date: "2025-04-27",
    type: "import"
  },
  {
    id: "TR-7830",
    product: "Machinery",
    country: "Germany",
    amount: 289500,
    status: "pending",
    date: "2025-04-26",
    type: "export"
  },
  {
    id: "TR-7831",
    product: "Textiles",
    country: "India",
    amount: 167200,
    status: "processing",
    date: "2025-04-25",
    type: "import"
  },
  {
    id: "TR-7832",
    product: "Agriculture",
    country: "Brazil",
    amount: 432800,
    status: "completed",
    date: "2025-04-25",
    type: "export"
  },
  {
    id: "TR-7833",
    product: "Automobiles",
    country: "Japan",
    amount: 912500,
    status: "pending",
    date: "2025-04-24",
    type: "import"
  },
];

const statusStyles = {
  completed: "bg-green-100 text-green-700",
  pending: "bg-amber-100 text-amber-700",
  processing: "bg-blue-100 text-blue-700"
};

const typeStyles = {
  import: "bg-trading-navy-100 text-trading-navy-700",
  export: "bg-trading-blue-100 text-trading-blue-700"
};

const RecentTradesList: React.FC = () => {
  return (
    <Card className="trade-card col-span-full">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-lg font-semibold">Recent Trades</CardTitle>
        <Button variant="ghost" size="sm" className="gap-1">
          View All <ChevronRight className="h-4 w-4" />
        </Button>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-muted/50">
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">ID</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Product</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Type</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Country</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Amount</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Status</th>
                  <th className="whitespace-nowrap px-4 py-3 text-left font-medium">Date</th>
                </tr>
              </thead>
              <tbody>
                {recentTrades.map((trade) => (
                  <tr key={trade.id} className="border-t hover:bg-muted/50">
                    <td className="whitespace-nowrap px-4 py-3 font-medium">{trade.id}</td>
                    <td className="whitespace-nowrap px-4 py-3">{trade.product}</td>
                    <td className="whitespace-nowrap px-4 py-3">
                      <Badge variant="outline" className={cn(typeStyles[trade.type])}>
                        {trade.type}
                      </Badge>
                    </td>
                    <td className="whitespace-nowrap px-4 py-3">{trade.country}</td>
                    <td className="whitespace-nowrap px-4 py-3">
                      {trade.amount.toLocaleString('en-US', { 
                        style: 'currency', 
                        currency: 'USD',
                        maximumFractionDigits: 0
                      })}
                    </td>
                    <td className="whitespace-nowrap px-4 py-3">
                      <Badge variant="outline" className={cn(statusStyles[trade.status])}>
                        {trade.status}
                      </Badge>
                    </td>
                    <td className="whitespace-nowrap px-4 py-3">{trade.date}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default RecentTradesList;
