
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowUpRight } from "lucide-react";

interface InsightItem {
  title: string;
  description: string;
  impact: "positive" | "negative" | "neutral";
}

const insights: InsightItem[] = [
  {
    title: "Global Steel Price Increase",
    description: "Steel prices expected to rise 8.5% in Q2 due to supply chain disruptions.",
    impact: "negative"
  },
  {
    title: "EU-ASEAN Trade Agreement",
    description: "New trade agreement reduces tariffs by 15% on agricultural exports.",
    impact: "positive"
  },
  {
    title: "Shipping Delays in Pacific Routes",
    description: "Average shipping times increased by 12 days affecting electronics imports.",
    impact: "negative"
  },
  {
    title: "New Market Access in South America",
    description: "Brazil opens previously restricted sectors to foreign companies.",
    impact: "positive"
  }
];

const impactColors = {
  positive: "text-green-600",
  negative: "text-red-600",
  neutral: "text-blue-600"
};

const MarketInsightsCard: React.FC = () => {
  return (
    <Card className="trade-card col-span-1 md:col-span-2 lg:col-span-2">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-lg font-semibold">Market Insights</CardTitle>
        <button className="text-sm font-medium text-primary flex items-center gap-1">
          Full Analysis <ArrowUpRight className="h-4 w-4" />
        </button>
      </CardHeader>
      <CardContent>
        <div className="space-y-5">
          {insights.map((insight, i) => (
            <div key={i} className="space-y-1">
              <div className="flex items-center gap-2">
                <div className={`h-2 w-2 rounded-full ${impactColors[insight.impact]}`} />
                <h4 className="font-medium">{insight.title}</h4>
              </div>
              <p className="text-sm text-muted-foreground pl-4">{insight.description}</p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default MarketInsightsCard;
