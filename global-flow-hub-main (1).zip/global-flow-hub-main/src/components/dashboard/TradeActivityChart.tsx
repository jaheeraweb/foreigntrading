
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  TooltipProps 
} from "recharts";
import { cn } from "@/lib/utils";

const data = [
  { name: "Jan", imports: 4000, exports: 2400 },
  { name: "Feb", imports: 3000, exports: 1398 },
  { name: "Mar", imports: 2000, exports: 9800 },
  { name: "Apr", imports: 2780, exports: 3908 },
  { name: "May", imports: 1890, exports: 4800 },
  { name: "Jun", imports: 2390, exports: 3800 },
  { name: "Jul", imports: 3490, exports: 4300 },
  { name: "Aug", imports: 4000, exports: 2400 },
  { name: "Sep", imports: 3000, exports: 1398 },
  { name: "Oct", imports: 2000, exports: 9800 },
  { name: "Nov", imports: 2780, exports: 3908 },
  { name: "Dec", imports: 1890, exports: 4800 },
];

interface CustomTooltipProps extends TooltipProps<number, string> {}

const CustomTooltip: React.FC<CustomTooltipProps> = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-background/95 p-3 border rounded-md shadow-md">
        <p className="font-medium mb-1">{label}</p>
        {payload.map((entry, index) => (
          <div key={`item-${index}`} className="flex items-center gap-2 text-sm">
            <div className="w-2 h-2 rounded-full" style={{ backgroundColor: entry.color }} />
            <span className="font-medium">{entry.name}: </span>
            <span>{entry.value.toLocaleString('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 })}</span>
          </div>
        ))}
      </div>
    );
  }
  return null;
};

const TradeActivityChart: React.FC = () => {
  return (
    <Card className="col-span-full trade-card">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-semibold">Trade Activity</CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="annual">
          <div className="flex justify-between items-center mb-4">
            <TabsList>
              <TabsTrigger value="annual">Annual</TabsTrigger>
              <TabsTrigger value="quarterly">Quarterly</TabsTrigger>
              <TabsTrigger value="monthly">Monthly</TabsTrigger>
            </TabsList>
          </div>
          
          <TabsContent value="annual" className="h-[350px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={data}
                margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="name" />
                <YAxis 
                  tickFormatter={(value) => `$${value/1000}k`} 
                  width={65}
                />
                <Tooltip content={<CustomTooltip />} />
                <Line
                  type="monotone"
                  dataKey="exports"
                  stroke="#3389F6"
                  strokeWidth={2}
                  dot={{ r: 4 }}
                  activeDot={{ r: 6 }}
                />
                <Line
                  type="monotone"
                  dataKey="imports"
                  stroke="#003D81"
                  strokeWidth={2}
                  dot={{ r: 4 }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </TabsContent>
          
          <TabsContent value="quarterly" className="h-[350px]">
            <div className="flex h-full items-center justify-center text-muted-foreground">
              Quarterly data chart will appear here
            </div>
          </TabsContent>
          
          <TabsContent value="monthly" className="h-[350px]">
            <div className="flex h-full items-center justify-center text-muted-foreground">
              Monthly data chart will appear here
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default TradeActivityChart;
