
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

interface CountryData {
  country: string;
  value: number;
  percent: number;
  flagCode: string;
}

const topImportCountries: CountryData[] = [
  { country: "China", value: 2350000, percent: 85, flagCode: "CN" },
  { country: "Germany", value: 1850000, percent: 72, flagCode: "DE" },
  { country: "United States", value: 1420000, percent: 68, flagCode: "US" },
  { country: "Japan", value: 980000, percent: 52, flagCode: "JP" },
];

const TopCountriesCard: React.FC = () => {
  return (
    <Card className="trade-card col-span-1 md:col-span-2 lg:col-span-1">
      <CardHeader>
        <CardTitle className="text-lg font-semibold">Top Trading Partners</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {topImportCountries.map((item) => (
            <div key={item.country} className="space-y-1">
              <div className="flex items-center">
                <div className="flex items-center flex-1 gap-2">
                  <span className="text-xl">{getFlagEmoji(item.flagCode)}</span>
                  <span className="text-sm font-medium">{item.country}</span>
                </div>
                <span className="text-sm text-muted-foreground">
                  {item.value.toLocaleString('en-US', { 
                    style: 'currency', 
                    currency: 'USD',
                    maximumFractionDigits: 0
                  })}
                </span>
              </div>
              <Progress value={item.percent} className="h-2" />
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

// Helper function to convert country code to flag emoji
function getFlagEmoji(countryCode: string) {
  const codePoints = countryCode
    .toUpperCase()
    .split('')
    .map(char => 127397 + char.charCodeAt(0));
  return String.fromCodePoint(...codePoints);
}

export default TopCountriesCard;
