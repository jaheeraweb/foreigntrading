
import React, { useState } from "react";
import { Link } from "react-router-dom";
import { 
  LayoutDashboard, 
  Import, 
  ExternalLink, 
  ChartBar, 
  Settings, 
  Users,
  Menu,
  X,
  Globe,
  MessageSquare,
  Bell
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useIsMobile } from "@/hooks/use-mobile";

interface NavItemProps {
  icon: React.ElementType;
  label: string;
  to: string;
  active?: boolean;
  onClick?: () => void;
}

const NavItem = ({ icon: Icon, label, to, active, onClick }: NavItemProps) => (
  <li>
    <Link 
      to={to} 
      className={cn(
        "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors",
        active 
          ? "bg-sidebar-accent text-sidebar-accent-foreground" 
          : "text-sidebar-foreground/80 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
      )}
      onClick={onClick}
    >
      <Icon className="h-5 w-5" />
      <span>{label}</span>
    </Link>
  </li>
);

const SidebarNav = () => {
  const isMobile = useIsMobile();
  const [isOpen, setIsOpen] = useState(false);
  const [activePage, setActivePage] = useState("/");
  
  const toggleSidebar = () => setIsOpen(!isOpen);
  
  const handleNavClick = (path: string) => {
    setActivePage(path);
    if (isMobile) {
      setIsOpen(false);
    }
  };

  return (
    <>
      {/* Mobile menu toggle */}
      <div className="fixed left-4 top-4 z-50 md:hidden">
        <Button 
          variant="outline" 
          size="icon" 
          onClick={toggleSidebar}
          className="bg-background text-foreground"
        >
          {isOpen ? <X /> : <Menu />}
        </Button>
      </div>
      
      {/* Sidebar */}
      <aside 
        className={cn(
          "fixed inset-y-0 left-0 z-40 flex w-64 flex-col bg-sidebar border-r border-sidebar-border transition-transform duration-300 ease-in-out",
          isMobile && !isOpen ? "-translate-x-full" : "translate-x-0"
        )}
      >
        <div className="flex h-16 items-center gap-2 border-b border-sidebar-border px-6">
          <Globe className="h-6 w-6 text-sidebar-accent" />
          <span className="text-xl font-semibold tracking-tight text-sidebar-foreground">
            GlobalTrade
          </span>
        </div>
        
        <div className="flex-1 overflow-auto py-4">
          <nav className="space-y-1 px-2">
            <ul className="space-y-1">
              <NavItem 
                icon={LayoutDashboard} 
                label="Dashboard" 
                to="/" 
                active={activePage === "/"} 
                onClick={() => handleNavClick("/")}
              />
              <NavItem 
                icon={Import} 
                label="Imports" 
                to="/imports" 
                active={activePage === "/imports"} 
                onClick={() => handleNavClick("/imports")}
              />
              <NavItem 
                icon={ExternalLink} 
                label="Exports" 
                to="/exports" 
                active={activePage === "/exports"} 
                onClick={() => handleNavClick("/exports")}
              />
              <NavItem 
                icon={ChartBar} 
                label="Analytics" 
                to="/analytics" 
                active={activePage === "/analytics"} 
                onClick={() => handleNavClick("/analytics")}
              />
              <NavItem 
                icon={Users} 
                label="Partners" 
                to="/partners" 
                active={activePage === "/partners"} 
                onClick={() => handleNavClick("/partners")}
              />
              <NavItem 
                icon={MessageSquare} 
                label="Messages" 
                to="/messages" 
                active={activePage === "/messages"} 
                onClick={() => handleNavClick("/messages")}
              />
              <NavItem 
                icon={Settings} 
                label="Settings" 
                to="/settings" 
                active={activePage === "/settings"} 
                onClick={() => handleNavClick("/settings")}
              />
            </ul>
          </nav>
        </div>
        
        <div className="border-t border-sidebar-border p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className="h-8 w-8 rounded-full bg-sidebar-accent flex items-center justify-center text-white font-medium">
                JD
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-sidebar-foreground">John Doe</p>
                <p className="text-xs text-sidebar-foreground/70">Trade Manager</p>
              </div>
            </div>
            <Bell className="h-5 w-5 text-sidebar-foreground/70 hover:text-sidebar-foreground cursor-pointer" />
          </div>
        </div>
      </aside>
    </>
  );
};

export default SidebarNav;
