
import React from "react";
import { Outlet } from "react-router-dom";
import SidebarNav from "./SidebarNav";
import { cn } from "@/lib/utils";
import { useIsMobile } from "@/hooks/use-mobile";

const Layout: React.FC = () => {
  const isMobile = useIsMobile();

  return (
    <div className="flex min-h-screen bg-background">
      <SidebarNav />
      <main 
        className={cn(
          "flex-1 overflow-auto transition-all",
          isMobile ? "pl-0" : "pl-64"
        )}
      >
        <div className="container py-6 px-4 md:px-6 max-w-7xl">
          <Outlet />
        </div>
      </main>
    </div>
  );
};

export default Layout;
